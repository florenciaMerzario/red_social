-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 31-01-2021 a las 15:34:35
-- Versión del servidor: 10.4.16-MariaDB
-- Versión de PHP: 7.4.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `social`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `amigos`
--

CREATE TABLE `amigos` (
  `id` int(10) NOT NULL,
  `id_usuario` int(10) NOT NULL,
  `id_amigo` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `amigos`
--

INSERT INTO `amigos` (`id`, `id_usuario`, `id_amigo`) VALUES
(417, 112, 2),
(426, 113, 1),
(430, 109, 112),
(432, 112, 113),
(439, 114, 112),
(440, 115, 11),
(442, 114, 109),
(445, 11, 109),
(447, 11, 114),
(448, 117, 11),
(449, 113, 109),
(451, 118, 11),
(452, 118, 109),
(453, 125, 109),
(454, 125, 11),
(462, 116, 113),
(464, 116, 114),
(465, 116, 115),
(474, 116, 11),
(475, 169, 11),
(477, 113, 11);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `comentarios`
--

CREATE TABLE `comentarios` (
  `id_comentario` int(11) NOT NULL,
  `id_usuario` int(10) NOT NULL,
  `detalle_comentario` varchar(1000) NOT NULL,
  `id_mensaje` int(10) NOT NULL,
  `fecha` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `comentarios`
--

INSERT INTO `comentarios` (`id_comentario`, `id_usuario`, `detalle_comentario`, `id_mensaje`, `fecha`) VALUES
(309, 115, 'Yo la cambio cada quince dias', 42, '2021-01-23 22:56:10'),
(312, 116, 'Lo fundamental es ademas del cambio de agua el filtro', 42, '2021-01-25 14:17:43'),
(313, 116, 'No menos de una vez por semana', 42, '2021-01-25 14:18:28');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `mensajes`
--

CREATE TABLE `mensajes` (
  `id_mensaje` int(11) NOT NULL,
  `id_usuario` int(20) NOT NULL,
  `mensaje` varchar(500) NOT NULL,
  `fecha` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `mensajes`
--

INSERT INTO `mensajes` (`id_mensaje`, `id_usuario`, `mensaje`, `fecha`) VALUES
(42, 11, 'Quisiera saber cada cuanto se les cambia el agua...', '2020-07-05 10:31:18'),
(47, 11, 'Quisiera saber si los peces telescopicos no enfocan bien        ', '2020-07-12 10:06:44'),
(169, 11, 'Quisiera saber si los peces resiste ruidos molestos', '2020-11-11 18:13:24'),
(201, 114, 'Que cantidad de alimento le dan en un dia', '2021-01-23 18:32:18');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `mensajesprivados`
--

CREATE TABLE `mensajesprivados` (
  `id_mensajePrivado` int(10) NOT NULL,
  `id_usuarioEnvia` int(10) NOT NULL,
  `id_usuarioRecibe` int(11) NOT NULL,
  `mensaje` varchar(1000) NOT NULL,
  `fecha` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `mensajesprivados`
--

INSERT INTO `mensajesprivados` (`id_mensajePrivado`, `id_usuarioEnvia`, `id_usuarioRecibe`, `mensaje`, `fecha`) VALUES
(202, 112, 11, 'hola Mr Bean', '2021-01-19 15:34:12'),
(210, 113, 11, 'hola mr bean soy patricio', '2021-01-21 13:13:43'),
(212, 114, 112, 'hola Santi soy brad', '2021-01-23 22:54:52'),
(232, 113, 112, 'hola santi soy pato', '2021-01-31 15:26:18');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE `usuarios` (
  `id_usuario` int(10) NOT NULL,
  `password` varchar(255) NOT NULL,
  `nombre` varchar(50) DEFAULT NULL,
  `email` varchar(255) NOT NULL,
  `imagen` varchar(255) NOT NULL,
  `alt` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`id_usuario`, `password`, `nombre`, `email`, `imagen`, `alt`) VALUES
(11, '$2y$10$ZrZCWfRmywO/0UQ7MyHMM.Ep6wEGB6voyT.sOsvjItas1UJdKW.dC', 'Mr Bean', 'mr@gmail.com', '20210110170211.jpg', ''),
(109, '$2y$10$7/lg4.Qf0q7pliuhrvny5e7cmgE0FjvLBgpX660ZRsrirk3FMDhky', 'flavio', 'flavio@gmail.com', '20210115232613.jpg', '20210115232613.jpg'),
(112, '$2y$10$yubq83mJAJIsYpBQqeCO1uq04wPs9a.9C36ocndS0H.PeVlZq6msG', 'Santi', 'santi@gmail.com', '20210121131647.png', '20210119150702.png'),
(113, '$2y$10$/PkEt0alqkq.6iINWCdNIe6ZuCzclb/sxOliS8ahZLCdPUe1GvcHO', 'Patricio', 'pato@gmail.com', '20210121131052.jpg', '20210121131052.jpg'),
(114, '$2y$10$36TN/mZ2oGB55nnIhqkEcuUawHH725e2t9fMQQw509M1Cte4Viwnq', 'Brad', 'brad@gmail.com', '20210122192108.png', '20210122192108.png'),
(115, '$2y$10$/ga65WJb33.V7t02Dcha.Oz24Obr7UN.l3q9GO0eBhdO141dSdV02', 'Richard', 'richard@gmail.com', '20210127173925.png', '20210123225552.png'),
(116, '$2y$10$BhG9ZUUUb9pv2pK.REpX7el59vwawngSTPnOdkswHc46cKGbjXQ3W', 'juan', 'juan@gmail.com', '20210125141701.png', '20210125141701.png'),
(136, '$2y$10$33PlzDDXCcCGHYb1qMP/g.51KZg3ao.YVqWhYGKDK6096V5pLIL4q', 'Patricio 7', 'patricio7@gmail.com', '20210129153412.png', '20210129153412.png'),
(169, '$2y$10$PpvM57/7PBRoLCvEev6BX.4cU2sPWOmZOJiXzHTn4gdo6LRArXTbe', 'juan1', 'juan1@gmail.com', '20210130181450.png', '20210130181450.png');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `amigos`
--
ALTER TABLE `amigos`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `comentarios`
--
ALTER TABLE `comentarios`
  ADD PRIMARY KEY (`id_comentario`),
  ADD KEY `id_mensaje` (`id_mensaje`),
  ADD KEY `id_usuario` (`id_usuario`);

--
-- Indices de la tabla `mensajes`
--
ALTER TABLE `mensajes`
  ADD PRIMARY KEY (`id_mensaje`),
  ADD KEY `id_usuario` (`id_usuario`),
  ADD KEY `id_mensaje` (`id_mensaje`),
  ADD KEY `mensaje` (`mensaje`);

--
-- Indices de la tabla `mensajesprivados`
--
ALTER TABLE `mensajesprivados`
  ADD PRIMARY KEY (`id_mensajePrivado`);

--
-- Indices de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id_usuario`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `amigos`
--
ALTER TABLE `amigos`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=478;

--
-- AUTO_INCREMENT de la tabla `comentarios`
--
ALTER TABLE `comentarios`
  MODIFY `id_comentario` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=335;

--
-- AUTO_INCREMENT de la tabla `mensajes`
--
ALTER TABLE `mensajes`
  MODIFY `id_mensaje` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=217;

--
-- AUTO_INCREMENT de la tabla `mensajesprivados`
--
ALTER TABLE `mensajesprivados`
  MODIFY `id_mensajePrivado` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=233;

--
-- AUTO_INCREMENT de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id_usuario` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=170;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `comentarios`
--
ALTER TABLE `comentarios`
  ADD CONSTRAINT `comentarios_ibfk_1` FOREIGN KEY (`id_mensaje`) REFERENCES `mensajes` (`id_mensaje`) ON DELETE CASCADE;

--
-- Filtros para la tabla `mensajes`
--
ALTER TABLE `mensajes`
  ADD CONSTRAINT `mensajes_ibfk_1` FOREIGN KEY (`id_usuario`) REFERENCES `usuarios` (`id_usuario`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
